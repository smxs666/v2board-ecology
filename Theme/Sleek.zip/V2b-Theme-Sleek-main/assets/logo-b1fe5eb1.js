const o=""+new URL("../img/logo.png",import.meta.url).href;export{o as _};
