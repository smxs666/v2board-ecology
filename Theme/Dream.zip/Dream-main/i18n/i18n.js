window.language = [
  'zh_CN',
  'en',
]
