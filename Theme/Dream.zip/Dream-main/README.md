# Dream
适配 V2Board v1.7.4/其他版本自测 版本的前端主题

# 介绍
本主题由@geekui分享  
分享人TG：https://t.me/geekui  
TG频道：https://t.me/V2boradUI  

# 安装
下载到theme目录过后要修改当前文件夹名为Dream，然后在后台选择主题 【Dream】 就行了

# 产品演示
![image](https://github.com/Bitsea1/Dream/assets/100432611/3a2e7c3f-33c4-43d6-9233-7e4d615c71f8)
![image](https://github.com/Bitsea1/Dream/assets/100432611/16e4d0d0-d006-4cca-a9b8-7deeb471486b)
![image](https://github.com/Bitsea1/Dream/assets/100432611/36c94d5c-08d9-46a7-88b9-3d67fdb95bc1)
![image](https://github.com/Bitsea1/Dream/assets/100432611/787254b5-2bb7-4f07-9399-18e696d8cedc)
![image](https://github.com/Bitsea1/Dream/assets/100432611/2da58b32-7484-411b-9ec0-50bd276d92e7)
![image](https://github.com/Bitsea1/Dream/assets/100432611/05c437a2-40e9-41ee-b477-15d1658933d1)
![image](https://github.com/Bitsea1/Dream/assets/100432611/945a2a26-3177-4332-825b-278093271553)
![image](https://github.com/Bitsea1/Dream/assets/100432611/dc34a6b9-47c1-4ff7-9cbb-63f02b5f9b59)
