# vitayr
适配 V2Board v1.5.1/v1.5.4/v1.6.0/v1.7.0/v1.7.2/v1.7.3/v1.7.4 版本的前端主题

# 介绍
本主题由@geekui分享  
分享人TG：https://t.me/geekui  
TG频道：https://t.me/V2boradUI  

# 日志
1、修复语言切换  
2、修复后台面板改色

# 安装
下载到theme目录过后要修改当前文件夹名为vitayr，然后在后台选择主题 【vitayr】 就行了

# 产品演示
![image](https://github.com/Bitsea1/vitayr/assets/100432611/837a4c05-73f6-4b7d-8efb-ad815663c084)
![image](https://github.com/Bitsea1/vitayr/assets/100432611/27aef837-e6ea-41af-b201-a15f15e5edfc)
![image](https://github.com/Bitsea1/vitayr/assets/100432611/6ebec4ac-c3f6-41f7-8fac-7486b3986e46)
